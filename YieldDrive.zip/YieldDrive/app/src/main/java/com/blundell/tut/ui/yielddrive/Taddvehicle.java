package com.blundell.tut.ui.yielddrive;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Taddvehicle extends AppCompatActivity {
    Button mRegisterBtn;
    EditText vno;
    EditText dname;
    EditText dmb;
    EditText vcap;
    EditText cnamet;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_taddvehicle);
        vno=findViewById(R.id.editText3);
        dname=findViewById(R.id.editText5);
        dmb=findViewById(R.id.editText4);
        vcap=findViewById(R.id.editText6);
        cnamet=findViewById(R.id.editText7);
        mRegisterBtn=findViewById(R.id.button3);
        db=openOrCreateDatabase("yield", Context.MODE_PRIVATE,null);
        db.execSQL("create table if not exists vreg1 (vno varchar, dname varchar, dmb varchar,vcap varchar,cnamet varchar);");
        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String memail=vno.getText().toString().trim();
                final String password=dname.getText().toString().trim();
                final String fullName=dmb.getText().toString().trim();
                final String phone=vcap.getText().toString().trim();
                if(TextUtils.isEmpty(fullName)||TextUtils.isEmpty(phone)||TextUtils.isEmpty(memail)||TextUtils.isEmpty(password))
                {
                    Toast.makeText(Taddvehicle.this,"Please Enter all the fields",Toast.LENGTH_LONG).show();
                    return;
                }

                if(TextUtils.isEmpty(memail))
                {
                    vno.setError("Vechicle No. is Required.");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    dname.setError("Email Id id Required.");
                    return;
                }
                if(TextUtils.isEmpty(fullName))
                {
                    dmb.setError("Mobile No. is Required.");
                    return;
                }
                if(TextUtils.isEmpty(phone))
                {
                    vcap.setError("Capacity No is Required.");
                    return;
                }
                db.execSQL("insert into vreg1 values('"+vno.getText()+"','"+dname.getText()+"','"+dmb.getText()+"','"+vcap.getText()+"','"+cnamet.getText()+"');");
                Toast.makeText(Taddvehicle.this, "Vehicle Registered Successfully", Toast.LENGTH_LONG).show();
                clr();
                startActivity(new Intent(Taddvehicle.this,Thome.class));

            }
        });


    }
    public void clr()
    {
        vno.setText("");
        dname.setText("");
        dmb.setText("");
        vcap.setText("");
    }

}
