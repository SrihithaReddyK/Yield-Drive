package com.blundell.tut.ui.yielddrive;
import android.app.Application;

public class GlobalClass extends Application {
    public String UserName;


    public String GetUsername()
    {
        return UserName;
    }

    public void Setusername(String _susername)
    {
        UserName=_susername;

    }


}