package com.blundell.tut.ui.yielddrive;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Thome extends AppCompatActivity {
    TextView uid2;
    Button vreg,vh,vp,vlout;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thome);
        final GlobalClass gv=(GlobalClass)getApplicationContext();
        uid2=findViewById(R.id.uid2);
        uid2.setText(gv.GetUsername().toString());
        vreg=findViewById(R.id.vreg);
        vh=findViewById(R.id.vhistory);
        vp=findViewById(R.id.profile);
        vlout=findViewById(R.id.lout);
        db=openOrCreateDatabase("yield", Context.MODE_PRIVATE,null);
        db.execSQL("create table if not exists freg (uid varchar, emid varchar,pass varchar,mbl varchar);");
        db.execSQL("create table if not exists treg (uid varchar, emid varchar,pass varchar,mbl varchar);");
        vreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Thome.this,Taddvehicle.class));
            }
        });
        vh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Thome.this,Tbookinginformation.class));
            }
        });
        vp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c=db.rawQuery("SELECT * FROM treg WHERE uid='"+uid2.getText()+"'", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("Driver ID: "+c.getString(0)+"\n");
                    buffer.append("Email Id: "+c.getString(1)+"\n");
                    buffer.append("Password: "+c.getString(2)+"\n");
                    buffer.append("Mobile No: "+c.getString(3)+"\n");
                }
                showMessage("Farmer Profile Details", buffer.toString());
            }
        });
        vlout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Thome.this,Home.class));
            }
        });
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public void onBackPressed() {
        // TODO Auto-generated method stub
        Toast.makeText(getApplicationContext(), "Please press Logout button", Toast.LENGTH_LONG).show();
    }
}