package com.blundell.tut.ui.yielddrive;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Fbookinginformation extends AppCompatActivity {
    TextView uid2;
    ArrayList<String> list1;
    ArrayAdapter adapter;
    SQLiteDatabase db;
    ListView l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fbookinginformation);
        final GlobalClass gv=(GlobalClass)getApplicationContext();
        uid2=findViewById(R.id.uid2);
        uid2.setText(gv.GetUsername().toString());
        l =findViewById(R.id.listview);
        db=openOrCreateDatabase("yield", Context.MODE_PRIVATE,null);
        db.execSQL("create table if not exists vbooking (fid varchar,vno varchar, dname varchar, dmb varchar,vcap varchar,lfrom varchar,lto varchar,sdate varchar,stime varchar,ccap varchar,dstatus varchar);");
        final ArrayList<String> list = new ArrayList<String>();
        list1 = new ArrayList<String>();
        Cursor res=db.rawQuery("SELECT * FROM vbooking where fid='"+uid2.getText()+"'", null);
        if(res.getCount()!=0)
        {
            while (res.moveToNext())
            {
                list.add("Vehicle No.:   "+res.getString(1)+"\n Driver Name:   "+res.getString(2)+"\n"+" Mobile No.:   "+res.getString(3)+"\n"+"Vehicle Capacity:   "+res.getString(4)+"\n"+"From:   "+res.getString(5)+"\n"+"To:   "+res.getString(6)+"\n"+"Date:   "+res.getString(7)+"\n"+"Time:   "+res.getString(8)+"\n"+"Crop Capacity (Q):   "+res.getString(9)+"\n"+"Avaliable Capacity (Q):   "+res.getString(10));
            }
        }
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list);
        l.setAdapter(adapter);
    }
}