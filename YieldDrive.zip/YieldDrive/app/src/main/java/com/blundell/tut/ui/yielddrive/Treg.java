package com.blundell.tut.ui.yielddrive;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Treg extends AppCompatActivity {
    TextView mLoginBtn;
    Button mRegisterBtn;
    EditText mFullName;
    EditText mPassword;
    EditText mEmail;
    EditText mPhone;
    ProgressBar progressBar;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treg);
        mFullName=findViewById(R.id.editText3);
        mPassword=findViewById(R.id.editText4);
        mEmail=findViewById(R.id.editText5);
        mPhone=findViewById(R.id.editText6);
        progressBar=findViewById(R.id.progressBar4);
        mLoginBtn=findViewById(R.id.textView4);
        mRegisterBtn=findViewById(R.id.button3);
        db=openOrCreateDatabase("yield", Context.MODE_PRIVATE,null);
        db.execSQL("create table if not exists freg (uid varchar, emid varchar,pass varchar,mbl varchar);");
        db.execSQL("create table if not exists treg (uid varchar, emid varchar,pass varchar,mbl varchar);");
        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email=mEmail.getText().toString().trim();
                final String password=mPassword.getText().toString().trim();
                final String fullName=mFullName.getText().toString().trim();
                final String phone=mPhone.getText().toString().trim();
                if(TextUtils.isEmpty(fullName)||TextUtils.isEmpty(phone)||TextUtils.isEmpty(email)||TextUtils.isEmpty(password))
                {
                    Toast.makeText(Treg.this,"Please Enter all the fields",Toast.LENGTH_LONG).show();
                    return;
                }

                if(TextUtils.isEmpty(fullName))
                {
                    mFullName.setError("User Name is Required.");
                    return;
                }
                if(TextUtils.isEmpty(email))
                {
                    mEmail.setError("Email Id id Required.");
                    return;
                }
                if(!email.matches(emailPattern))
                {
                    mEmail.setError("Enter Valid Email id.");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    mPassword.setError("Password is Required.");
                    return;
                }
                /*
                if(password.length()<4)
                {
                    mPassword.setError("Password must be >= 4 Characcters.");
                    return;
                }
                */
                if(TextUtils.isEmpty(phone))
                {
                    mPhone.setError("Mobile No is Required.");
                    return;
                }
                if(phone.length()!=10)
                {
                    mPhone.setError("Enter 10 Digit Mobile No");
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                Cursor c=db.rawQuery("SELECT * FROM freg WHERE uid='"+mFullName.getText()+"'", null);
                if(c.moveToFirst())
                {
                    Toast.makeText(getApplicationContext(),"User ID Already Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                Cursor c1=db.rawQuery("SELECT * FROM treg WHERE uid='"+mFullName.getText()+"'", null);
                if(c1.moveToFirst())
                {
                    Toast.makeText(getApplicationContext(),"User ID Already Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                db.execSQL("insert into treg values('"+mFullName.getText()+"','"+mEmail.getText()+"','"+mPassword.getText()+"','"+mPhone.getText()+"');");
                Toast.makeText(Treg.this, "Transport Registration Successfully Done", Toast.LENGTH_LONG).show();
                clr();
                startActivity(new Intent(Treg.this,Home.class));

            }
        });
        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Treg.this,Home.class));
            }
        });


    }
    public void clr()
    {
        mFullName.setText("");
        mEmail.setText("");
        mPassword.setText("");
        mPhone.setText("");
    }

}
